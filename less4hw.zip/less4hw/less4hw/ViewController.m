//
//  ViewController.m
//  less4hw
//
//  Created by Mac on 15.01.18.
//  Copyright © 2018 WarpTeam. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController () <MKMapViewDelegate, CLLocationManagerDelegate>

@property (nonatomic, strong) MKMapView *mapView;
@property (nonatomic, strong) CLLocationManager *locationManager;

@end

@implementation ViewController

- (void)dealloc
{
    [NSNotificationCenter.defaultCenter removeObserver:self
                                                  name:kGeocodeDidComplete
                                                object:nil];
}

- (instancetype)init
{
    if(self = [super init]) {
        [NSNotificationCenter.defaultCenter addObserver:self
                                               selector:@selector(geocodeComplete:)
                                                   name:kGeocodeDidComplete
                                                 object:nil];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    dispatch_async(dispatch_get_main_queue(), ^{
        CGRect frame =
        CGRectMake(
                   0,
                   0,
                   [UIScreen mainScreen].bounds.size.width,
                   [UIScreen mainScreen].bounds.size.height
                   );
        MKMapView *_mapView = [[MKMapView alloc] initWithFrame: frame];
        
        CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(55.7522200, 37.6155600);
        MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 100000, 100000);
        
        [_mapView setRegion: region animated: YES];
        [self.view addSubview:_mapView];
//    });
//
//    dispatch_async(dispatch_get_main_queue(), ^{
        CLLocationManager *_locationManager = [[CLLocationManager alloc] init];
        _locationManager.delegate = self;
//        NSLog(@"requestAlwaysAuthorization start");
        [_locationManager requestAlwaysAuthorization];
//        NSLog(@"requestAlwaysAuthorization done");
//    });
}

- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus) status {
    NSLog(@"didChangeAuthorizationStatus %d", status);
    
    if (status == kCLAuthorizationStatusAuthorizedAlways || status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        _locationManager.desiredAccuracy = kCLLocationAccuracyKilometer;
        _locationManager.distanceFilter = 500;
        [_locationManager startUpdatingLocation];
    }  else if (status != kCLAuthorizationStatusNotDetermined) {
        UIAlertController *alertController =
            [UIAlertController alertControllerWithTitle: @"Упс!"
                                                message: @"Не удалось определить текущий город!"
                                         preferredStyle:  UIAlertControllerStyleAlert
            ];
        [alertController addAction:[UIAlertAction actionWithTitle: @"Закрыть" style:(UIAlertActionStyleDefault) handler: nil]];
        
        [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertController animated: YES completion: nil];
    }
    
}
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray <CLLocation *> *)locations {
    CLLocation *location = [locations firstObject];
    if (location) {
        NSLog( @"%@", location);
        [self addressFromLocation:location];
        [_locationManager stopUpdatingLocation];
    }
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
    static NSString *identifier = @"MarkerIdentifier";

    MKMarkerAnnotationView *annotationView =
        (MKMarkerAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    
    if  (!annotationView) {
        annotationView =
            [[MKMarkerAnnotationView alloc]
                initWithAnnotation:annotation
                reuseIdentifier:identifier
            ];
        annotationView.canShowCallout = YES;
        annotationView.calloutOffset = CGPointMake (-5.0, 5.0);
        annotationView.rightCalloutAccessoryView =
            [UIButton buttonWithType: UIButtonTypeDetailDisclosure];
    }
    annotationView.annotation = annotation;
    
    return annotationView;
}

- (void)addressFromLocation:(CLLocation *)location {
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    
    [geocoder reverseGeocodeLocation:location
                   completionHandler:^(
                        NSArray <CLPlacemark *> *_Nullable placemarks,
                        NSError *_Nullable error
                                       ) {
        if ([placemarks count] > 0) {
            [NSNotificationCenter.defaultCenter
                postNotificationName:kGeocodeDidComplete
                              object:self
                            userInfo:[NSDictionary dictionaryWithObject:placemarks forKey:@"placemarks"]
            ];
        }
    }];
}

- (void)geocodeComplete:(NSArray <CLPlacemark *>*) placemarks {
    
    for (MKPlacemark *placemark in placemarks) {
        NSLog(@"%@", placemark.name);
    }
    
    MKPointAnnotation *annotation = [[MKPointAnnotation alloc] init];
    annotation.title = placemarks.firstObject.name;
    annotation.subtitle = placemarks.lastObject.name;
    annotation.coordinate = CLLocationCoordinate2DMake(55.7522200, 37.6155600);
    
    [_mapView addAnnotation:annotation];
    _mapView.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
