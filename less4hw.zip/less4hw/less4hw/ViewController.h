//
//  ViewController.h
//  less4hw
//
//  Created by Mac on 15.01.18.
//  Copyright © 2018 WarpTeam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface ViewController : UIViewController


@end

#define kGeocodeDidComplete @"GeocodeDidComplete"
